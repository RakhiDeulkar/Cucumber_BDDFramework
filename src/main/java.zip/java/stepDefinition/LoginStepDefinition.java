package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.java.en.Given;


public class LoginStepDefinition {
	WebDriver driver;
	
	@Given("^user is already on Login Page$")
	public void user_is_already_on_Login_Page(){
		
		System.setProperty("webdriver.chrome.driver","C:\\Chrome\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://freecrm.co.in/");
		
		//driver.findElement(By.xpath(".//*[@class='btn btn-primary btn-xs-2 btn-shadow 
		//btn-rect btn-icon btn-icon-left']")).click();
		WebElement Loginb= driver.findElement(By.xpath(".//*[@class='btn btn-primary btn-xs-2 btn-shadow btn-rect btn-icon btn-icon-left']"));
		JavascriptExecutor js= (JavascriptExecutor)driver;
	js.executeScript("arguments[0].click();",Loginb);
	}
	
	@When("^title of login page is Free CRM$")
	public void title_of_login_page_is_Free_CRM(){
		
		
		String Title=driver.getTitle();
		System.out.println(Title);
		Assert.assertEquals("Cogmento CRM",Title);
	}
	
	@Then("^user enters username and password$")
	public void user_enters_username_and_password(){
		driver.findElement(By.xpath(".//*[@name='email']")).
		sendKeys("rakhideulkar10@gmail.com");
		driver.findElement(By.xpath(".//*[@name='password']")).
		sendKeys("Rakhi@123");
	
	    
	}
	@Then("^user clicks on Login button$")
	public void user_clicks_on_Login_button() {
		//driver.findElement(By.xpath(".//*[@class='ui fluid large blue submit button']")).click();
		//	Thread.sleep(2000);
		WebElement Loginbtn= driver.findElement(By.xpath(".//*[@class='ui fluid large blue submit button']"));
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",Loginbtn);
		
	}

	@Then("^user is on HomePage$")
	public void user_is_on_HomePage() {
		/*boolean status=driver.findElement(By.xpath(".//*[@class='header item']")).isDisplayed();
				Assert.assertTrue(status);
				System.out.println("Login  Successfull");*/
		String title=driver.getTitle();
		System.out.println("Home Page title: "+title);
		Assert.assertEquals("Cogmento CRM", title);
					
	}


 
}
